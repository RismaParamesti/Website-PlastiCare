<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PlastiCare - Cara Kelola Sampah</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #4CAF50;
        }
        header {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        header h1 {
            margin: 0;
            font-size: 36px;
            margin-left: 10px; /* Beri sedikit jarak antara logo dan teks */
            font-family: 'Times New Roman', cursive; /* Terapkan font Pacifico */
        }
        header img.logo {
            height: 70px; /* Tinggi logo yang lebih besar */
            width: 80px;
            margin-right: 10px; /* Jarak antara logo dan teks */
        }
        .login-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: auto;
            transition: background-color 0.3s;
        }
        .login-btn:hover {
            background-color: #45a049;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: white;
            padding: 15px;
            height: calc(100vh - 60px);
            position: fixed;
            top: 80px; /* Pastikan sidebar dimulai dari bawah header */
            left: 0;
            overflow: auto;
            transition: width 0.3s;
            z-index: 999; /* Pastikan sidebar di bawah header */
        }
        .sidebar.collapsed {
            width: 60px;
        }
        .sidebar.collapsed + .container {
    margin-left: 60px; /* Lebar sidebar ketika dalam kondisi collapse */
}
        .sidebar.collapsed h2, .sidebar.collapsed ul {
            display: none;
        }
        .sidebar.collapsed .toggle-btn {
            text-align: center;
        }
        .toggle-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: left;
            cursor: pointer;
            margin-bottom: 10px;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar h2 {
            text-align: center;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar ul li {
            padding: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar ul li a:hover {
            background-color: #575757;
            padding-left: 5px;
            transition: 0.3s;
        }
        .navbar {
            background-color: #000;
            overflow: hidden;
        }
        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        .navbar a:hover {
            background-color: #ddd;
            color: #4CAF50;
        }
        .navbar a.active {
            background-color: #575757;
            color: white;
        }
        .navbar .login {
            float: right;
        }
        .container {
            padding: 20px;
            margin-left: 150px; /* Sesuaikan margin dengan lebar sidebar */
            margin-right: auto;
         margin-top: 20px;
        }
        .title {
            text-align: center;
            margin: 20px 0;
            color: #4CAF50;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
        }
        .grid-item {
            background-color: #4CAF50;
            padding: 20px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: white;
        }
        .grid-item img {
            max-width: 100%;
            height: auto;
        }
        .grid-item p {
            margin-top: 10px;
            color: white;
            font-weight: bold;
        }
    </style>
</head>
<body>
<header>
    <img src="logonew.png" alt="Bank Sampah Logo" class="logo"> <!-- Tambahkan elemen gambar logo di sini -->
    <h1>PlastiCare</h1>
    <button onclick="redirectToAdminLogin()" class="login-btn">Login</button>
</header>
<script>
    function redirectToAdminLogin() {
        window.location.href = "beranda_login.php";
    }
    </script>
<div class="container">
    <div class="sidebar" id="sidebar">
        <div class="toggle-btn" onclick="toggleSidebar()">☰</div>
        <ul>
            <li><a href="pengenalansampah.php">Informasi Pengenalan Sampah Plastik</a></li>
            <li><a href="cara_kelola_sampah.php">Cara Mengelola Sampah Plastik</a></li>
            <li><a href="login_form.php">Informasi Pengajuan penjemputan Sampah Plastik</a></li>
            <li><a href="tentang_website.php">Tentang Website</a></li>
            <li><a href="FAQ.php">FAQ</a></li>
        </ul>
    </div>
    <div class="container">
        <h1 class="title">Mau Daur Ulang Sampah Plastikmu?</h1>
        <div class="grid-container">
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=tas_belanja"><img src="assets/tasplastik.jpg" alt="Tas Belanja"></a>
                <p>Tas Belanja</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=baju_kreasi"><img src="assets/bajuplastik.jpg" alt="Baju Kreasi"></a>
                <p>Baju Kreasi</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=pot_cantik"><img src="assets/potplastik.jpg" alt="Pot Cantik"></a>
                <p>Pot Cantik</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=bunga_hias"><img src="assets/bungahias.jpg" alt="Bunga Hias"></a>
                <p>Bunga Hias</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=tas_belanja2"><img src="assets/tasplastik2.jpg" alt="Tas Belanja"></a>
                <p>Tas Belanja</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=baju_kreasi2"><img src="assets/bajuplastik2.jpg" alt="Baju Kreasi"></a>
                <p>Baju Kreasi</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=pot_cantik2"><img src="assets/potplastik2.jpg" alt="Pot Cantik"></a>
                <p>Pot Cantik</p>
            </div>
            <div class="grid-item">
                <a href="detail_kelola_sampah.php?item=bunga_hias2"><img src="assets/bungahias2.jpg" alt="Bunga Hias"></a>
                <p>Bunga Hias</p>
            </div>
        </div>
    </div>
    <script>
    function toggleSidebar() {
        var sidebar = document.getElementById('sidebar');
        var mainContent = document.getElementById('main-content');
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('collapsed');
    }
</script>
</body>
</html>