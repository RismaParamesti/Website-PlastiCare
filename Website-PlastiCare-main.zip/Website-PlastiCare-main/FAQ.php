<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - PlastiCare</title>
    <style>
        body {
            font-family: 'Times New Roman', serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        header {
            width: 100%;
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        header h1 {
            margin: 0;
            font-size: 36px;
            margin-left: 10px; /* Beri sedikit jarak antara logo dan teks */
            font-family: 'Times New Roman', cursive; /* Terapkan font Pacifico */
        }
        header img.logo {
            height: 70px; /* Tinggi logo yang lebih besar */
            width: 80px;
            margin-right: 10px; /* Jarak antara logo dan teks */
        }
        .login-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-left: auto;
            transition: background-color 0.3s;
        }
        .login-btn:hover {
            background-color: #45a049;
        }
        .sidebar {
            width: 250px;
            background: #333;
            color: white;
            padding: 15px;
            height: calc(100vh - 60px);
            position: fixed;
            top: 80px; /* Pastikan sidebar dimulai dari bawah header */
            left: 0;
            overflow: auto;
            transition: width 0.3s;
            z-index: 999; /* Pastikan sidebar di bawah header */
        }
        .sidebar.collapsed {
            width: 60px;
        }
        .sidebar.collapsed h2, .sidebar.collapsed ul {
            display: none;
        }
        .sidebar.collapsed .toggle-btn {
            text-align: center;
        }
        .toggle-btn {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: left;
            cursor: pointer;
            margin-bottom: 10px;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar h2 {
            text-align: center;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar ul {
            list-style-type: none;
            padding: 0;
            margin-top: 20px; /* Tambahkan margin atas untuk memberi jarak dari header */
        }
        .sidebar ul li {
            padding: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar ul li a:hover {
            background-color: #575757;
            padding-left: 5px;
            transition: 0.3s;
        }
        .sidebar.collapsed + .container {
    margin-left: 60px; /* Lebar sidebar ketika dalam kondisi collapse */
}
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            margin-left: 150px; /* Sesuaikan margin dengan lebar sidebar */
            margin-right: auto;
        }
        header {
            background-color: #4CAF50;
            color: white;
            padding: 20px;
            text-align: center;
            border-radius: 10px 10px 0 0;
        }
        header img.logo {
            height: 50px;
            margin-right: 10px;
            vertical-align: middle;
        }
        header h1 {
            display: inline;
            font-size: 24px;
            font-family: 'Times New Roman', serif;
        }
        .content {
            padding: 20px;
        }
        .content h2 {
            color: #388e3c;
        }
        .faq-item {
            margin-bottom: 20px;
            padding: 20px;
            background-color: #e0f2e9;
            border-radius: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .faq-item h3 {
            color: #388e3c;
            margin: 0;
        }
        .faq-item p {
            display: none;
            margin-top: 10px;
            line-height: 1.6;
        }
        .faq-item button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .faq-item button:hover {
            background-color: #45a049;
        }
        .footer {
            text-align: center;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border-radius: 0 0 10px 10px;
            margin-top: 20px;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const faqItems = document.querySelectorAll('.faq-item');
            faqItems.forEach(item => {
                const button = item.querySelector('button');
                const answer = item.querySelector('p');
                button.addEventListener('click', function() {
                    const isOpen = answer.style.display === 'block';
                    answer.style.display = isOpen ? 'none' : 'block';
                    button.textContent = isOpen ? 'Lihat Jawaban' : 'Tutup Jawaban';
                });
            });
        });
    </script>
</head>
<body>
<header>
    <img src="logonew.png" alt="Bank Sampah Logo" class="logo"> <!-- Tambahkan elemen gambar logo di sini -->
    <h1>PlastiCare</h1>
    <button onclick="redirectToAdminLogin()" class="login-btn">Login</button>
</header>
<script>
    function redirectToAdminLogin() {
        window.location.href = "beranda_login.php";
    }
    </script>
<div class="container">
    <div class="sidebar" id="sidebar">
        <div class="toggle-btn" onclick="toggleSidebar()">☰</div>
        <ul>
            <li><a href="pengenalansampah.php">Informasi Pengenalan Sampah Plastik</a></li>
            <li><a href="cara_kelola_sampah.php">Cara Mengelola Sampah Plastik</a></li>
            <li><a href="login_form.php">Informasi Pengajuan penjemputan Sampah Plastik</a></li>
            <li><a href="tentang_website.php">Tentang Website</a></li>
            <li><a href="FAQ.php">FAQ</a></li>
        </ul>
    </div>
    <div class="container">
        
        <div class="content">
            <h2>Frequently Asked Questions (FAQ)</h2>
            <div class="faq-item">
                <h3>Apa itu PlastiCare?</h3>
                <p>PlastiCare adalah inisiatif yang didedikasikan untuk mengurangi sampah plastik di lingkungan kita dengan menyediakan layanan penjemputan sampah plastik dari rumah Anda.</p>
                <button>Lihat Jawaban</button>
            </div>
            <div class="faq-item">
                <h3>Bagaimana cara kerja layanan penjemputan sampah plastik?</h3>
                <p>Anda dapat mendaftar atau menghubungi kami untuk jadwal penjemputan. Persiapkan sampah plastik yang sudah dipisahkan dari sampah lain dan tunggu petugas kami datang pada jadwal yang sudah disepakati.</p>
                <button>Lihat Jawaban</button>
            </div>
            <div class="faq-item">
                <h3>Apakah ada biaya untuk layanan penjemputan ini?</h3>
                <p>Layanan penjemputan sampah plastik dari PlastiCare tidak dikenakan biaya. Kami bertujuan untuk membantu masyarakat dalam mengelola sampah plastik mereka dengan lebih baik.</p>
                <button>Lihat Jawaban</button>
            </div>
            <div class="faq-item">
                <h3>Apa saja jenis sampah plastik yang bisa dijemput?</h3>
                <p>Kami menerima berbagai jenis sampah plastik seperti botol plastik, kantong plastik, bungkus plastik, dan lain-lain. Pastikan sampah plastik Anda bersih dan sudah dipisahkan dari sampah lainnya.</p>
                <button>Lihat Jawaban</button>
            </div>
            <div class="faq-item">
                <h3>Bagaimana saya bisa mendapatkan insentif dari PlastiCare?</h3>
                <p>Anda dapat menerima insentif berupa poin atau hadiah lainnya dari hasil daur ulang sampah plastik yang dikumpulkan. Insentif ini akan diberikan berdasarkan jumlah sampah plastik yang Anda sumbangkan.</p>
                <button>Lihat Jawaban</button>
            </div>
            <div class="faq-item">
                <h3>Bagaimana cara menghubungi PlastiCare?</h3>
                <p>Anda dapat menghubungi kami melalui email di info@banksampah.com atau telepon di 123-456-7890.</p>
                <button>Lihat Jawaban</button>
            </div>
        </div>
        <div class="footer">
            <p>&copy; 2024 PlastiCare. All rights reserved.</p>
        </div>
    </div>
    <script>
    function toggleSidebar() {
        var sidebar = document.getElementById('sidebar');
        var mainContent = document.getElementById('main-content');
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('collapsed');
    }
</script>
</body>
</html>
